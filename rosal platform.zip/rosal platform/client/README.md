# Todo Client

This is a Vite + React frontend. It proxies `/api` to `http://localhost:4000` (see `vite.config.js`).

## Setup (PowerShell)

```powershell
cd "c:/Users/Person 1/rosal platform/client"
npm install
npm run dev
```

Open http://localhost:5173
