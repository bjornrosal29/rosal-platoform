import React, { useEffect, useState } from 'react'

function App() {
  const [todos, setTodos] = useState([])
  const [title, setTitle] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editTitle, setEditTitle] = useState('')
  const API = '/api/todos'

  useEffect(() => {
    fetch(API)
      .then(r => r.json())
      .then(setTodos)
      .catch(console.error)
  }, [])

  async function addTodo(e) {
    e.preventDefault()
    if (!title.trim()) return
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title })
    })
    const todo = await res.json()
    setTodos(t => [todo, ...t])
    setTitle('')
  }

  async function toggle(todo) {
    const res = await fetch(`${API}/${todo.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: todo.title, completed: !todo.completed })
    })
    const updated = await res.json()
    setTodos(t => t.map(i => (i.id === updated.id ? updated : i)))
  }

  async function remove(id) {
    await fetch(`${API}/${id}`, { method: 'DELETE' })
    setTodos(t => t.filter(i => i.id !== id))
  }

  function startEdit(todo) {
    setEditingId(todo.id)
    setEditTitle(todo.title)
  }

  async function saveEdit(e) {
    e.preventDefault()
    if (!editTitle.trim()) return
    const res = await fetch(`${API}/${editingId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: editTitle.trim(), completed: todos.find(t => t.id === editingId).completed })
    })
    const updated = await res.json()
    setTodos(t => t.map(i => (i.id === updated.id ? updated : i)))
    setEditingId(null)
    setEditTitle('')
  }

  function cancelEdit() {
    setEditingId(null)
    setEditTitle('')
  }

  return (
    <div className="app">
      <h1>To‑Do</h1>
      <form onSubmit={addTodo} className="add-form">
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Add a task" />
        <button type="submit">Add</button>
      </form>

      <ul className="list">
        {todos.map(todo => (
          <li key={todo.id} className={todo.completed ? 'done' : ''}>
            <label>
              <input type="checkbox" checked={todo.completed} onChange={() => toggle(todo)} />
              {editingId === todo.id ? (
                <form onSubmit={saveEdit} className="edit-form">
                  <input value={editTitle} onChange={e => setEditTitle(e.target.value)} autoFocus />
                  <button type="submit">Save</button>
                  <button type="button" onClick={cancelEdit}>Cancel</button>
                </form>
              ) : (
                <span className="title" onDoubleClick={() => startEdit(todo)}>{todo.title}</span>
              )}
            </label>
            <button className="del" onClick={() => remove(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default App
