const fs = require('fs').promises
const path = require('path')

const file = path.join(__dirname, 'db.json')

async function readDB() {
  try {
    const text = await fs.readFile(file, 'utf8')
    return JSON.parse(text)
  } catch (err) {
    if (err.code === 'ENOENT') return { todos: [] }
    throw err
  }
}

async function writeDB(data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2), 'utf8')
}

module.exports = { readDB, writeDB }
