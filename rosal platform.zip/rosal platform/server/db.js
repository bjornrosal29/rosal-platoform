const sqlite3 = require('sqlite3').verbose()
const path = require('path')

const dbPath = path.join(__dirname, 'todos.db')
const db = new sqlite3.Database(dbPath)

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    completed INTEGER DEFAULT 0
  )`)
})

async function readDB() {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM todos ORDER BY id DESC', (err, rows) => {
      if (err) reject(err)
      else resolve({ todos: rows.map(row => ({ id: row.id, title: row.title, completed: !!row.completed })) })
    })
  })
}

async function writeDB(data) {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run('DELETE FROM todos', (err) => {
        if (err) return reject(err)
        const stmt = db.prepare('INSERT INTO todos (id, title, completed) VALUES (?, ?, ?)')
        data.todos.forEach(todo => {
          stmt.run(todo.id, todo.title, todo.completed ? 1 : 0)
        })
        stmt.finalize(resolve)
      })
    })
  })
}

module.exports = { readDB, writeDB }
