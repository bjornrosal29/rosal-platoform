const express = require('express')
const cors = require('cors')
const { readDB, writeDB } = require('./db')

const app = express()
app.use(cors())
app.use(express.json())

async function start() {
  app.get('/api/todos', async (req, res) => {
    const data = await readDB()
    const todos = (data.todos || []).slice().reverse()
    res.json(todos)
  })

  app.post('/api/todos', async (req, res) => {
    const { title } = req.body
    if (!title || !title.trim()) return res.status(400).json({ error: 'title required' })
    const data = await readDB()
    const todos = data.todos
    const id = todos.length ? Math.max(...todos.map(t => t.id)) + 1 : 1
    const todo = { id, title: title.trim(), completed: false }
    todos.push(todo)
    await writeDB(data)
    res.status(201).json(todo)
  })

  app.put('/api/todos/:id', async (req, res) => {
    const id = Number(req.params.id)
    const { title, completed } = req.body
    const data = await readDB()
    const todos = data.todos
    const idx = todos.findIndex(t => t.id === id)
    if (idx === -1) return res.status(404).end()
    todos[idx].title = title
    todos[idx].completed = Boolean(completed)
    await writeDB(data)
    res.json(todos[idx])
  })

  app.delete('/api/todos/:id', async (req, res) => {
    const id = Number(req.params.id)
    const data = await readDB()
    data.todos = data.todos.filter(t => t.id !== id)
    await writeDB(data)
    res.status(204).end()
  })

  const port = process.env.PORT || 4000
  app.listen(port, () => console.log(`Todo API listening on port ${port}`))
}

start().catch(err => {
  console.error('Failed to start server:', err)
  process.exit(1)
})
