# Todo Server

Simple Express API using SQLite (`better-sqlite3`).

## Setup

In PowerShell:

```powershell
cd "c:/Users/Person 1/rosal platform/server"
npm install
npm run start
```

The API runs on port `4000` by default and exposes `/api/todos` endpoints.
